import { Service } from '../types/services';

export const services: Service[] = [
  {
    title: 'Vinylové Podlahy',
    description: 'Moderní a odolné řešení pro váš domov',
    image: '/vinyl-bedroom-floor.jpg',
    alt: 'Luxusní vinylová podlaha v ložnici - tmavě hnědá vinylová podlaha s texturou dřeva v elegantní ložnici s klasickým nábytkem, bílými stěnami s dekorativními lištami a velkým oknem s béžovými závěsy',
    path: '/vinylove-podlahy'
  },
  {
    title: 'Dřevěné Podlahy',
    description: 'Klasická elegance přírodního dřeva',
    image: '/wooden-floor-kitchen.jpg',
    alt: 'Moderní kuchyně s luxusní dřevěnou podlahou - lesklá dřevěná podlaha s přirozenou kresbou v prostorné bílé kuchyni s ostrůvkem a prosklenou stěnou, doplněná zelenými rostlinami',
    path: '/drevene-podlahy'
  },
  {
    title: 'Laminátové Podlahy',
    description: 'Praktické a stylové podlahové krytiny',
    image: '/laminátová podlaha.jpg',
    alt: 'Elegantní laminátová podlaha v obývacím pokoji - kvalitní laminát s dekorem dubu, perfektně sladěný s moderním nábytkem a světlými stěnami, vytvářející útulnou atmosféru',
    path: '/laminatove-podlahy'
  },
  {
    title: 'Koberce',
    description: 'Komfortní řešení pro každý prostor',
    image: '/koberec.jpg',
    alt: 'Luxusní koberec v obytném prostoru - měkký, hustě tkaný koberec v neutrálních barvách, dokonale doplňující moderní interiér s důrazem na pohodlí a eleganci',
    path: '/koberce'
  },
  {
    title: 'Marmoleum',
    description: 'Ekologické a odolné podlahové krytiny',
    image: '/marmoleum.jpg',
    alt: 'Profesionálně instalované marmoleum v komerčním prostoru - ekologická podlahová krytina v moderním designu, vynikající svou odolností a snadnou údržbou',
    path: '/marmoleum'
  }
];