interface PricingItem {
  service: string;
  price: string;
}

interface PricingCategory {
  title: string;
  items: PricingItem[];
}

export const pricingData: PricingCategory[] = [
  {
    title: 'Příprava podkladu',
    items: [
      { service: 'Stržení a odvoz původních podlah', price: '48 Kč/m²' },
      { service: 'Přebroušení a očištění podkladu', price: '30 Kč/m²' },
      { service: 'Penetrace', price: '25 Kč/m²' },
      { service: 'Stěrkování podkladu vč. materiálu do 3 mm', price: '170 Kč/m²' },
      { service: 'Vyrovnání OSB deskami', price: '130 Kč/m²' },
    ],
  },
  {
    title: 'Pokládka laminátové podlahy',
    items: [
      { service: 'Pokládka laminátové podlahy', price: '145 Kč/m²' },
    ],
  },
  {
    title: 'Pokládka dřevěných podlah',
    items: [
      { service: 'Pokládka dřevěné plovoucí podlahy', price: '170 Kč/m²' },
      { service: 'Pokládka dřevěné plovoucí podlahy lepením', price: '250 Kč/m²' },
    ],
  },
  {
    title: 'Pokládka vinylových podlah',
    items: [
      { service: 'Pokládka vinylu lepením', price: '170 Kč/m²' },
      { service: 'Pokládka vinylové plovoucí podlahy', price: '150 Kč/m²' },
    ],
  },
  {
    title: 'Pokládka PVC podlah',
    items: [
      { service: 'Pokládka PVC podlah', price: '120 Kč/m²' },
      { service: 'Pokládka PVC podlah na volno', price: '85 Kč/m²' },
      { service: 'Svařování PVC', price: '28 Kč/m²' },
      { service: 'Sokl k PVC s materiálem', price: '49 Kč/bm' },
    ],
  },
  {
    title: 'Pokládka koberců',
    items: [
      { service: 'Pokládka koberců na volno', price: '85 Kč/m²' },
      { service: 'Pokládka koberců na pásku', price: '100 Kč/m²' },
      { service: 'Pokládka koberců lepením', price: '115 Kč/m²' },
      { service: 'Pokládka kobercových čtverců', price: '130 Kč/m²' },
      { service: 'Sokl kobercový a montáž', price: '49 Kč/bm' },
    ],
  },
  {
    title: 'Pokládka přírodního linolea – Marmoleum, Marmorette',
    items: [
      { service: 'Pokládka přirodního linolea', price: '180 Kč/m²' },
      { service: 'Fabion', price: '170 Kč/m²' },
      { service: 'Sokl SLK. MDF + montáž', price: '90 Kč/m²' },
    ],
  },
  {
    title: 'Montáž obvodových lišt',
    items: [
      { service: 'Montáž lepením', price: '43 Kč/bm' },
    ],
  },
  {
    title: 'Ostatní',
    items: [
      { service: 'Doprava', price: '10 Kč/km' },
      { service: 'Práce v hodinové sazbě', price: '350 Kč/hod' },
    ],
  },
];