import React from 'react';
import Section from '../components/Section';
import Button from '../components/Button';

const WoodenFlooringPage = () => {
  return (
    <>
      <Section
        backgroundImage="/wooden-floor-kitchen.jpg"
        dark
        content={
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-light mb-6">Dřevěné podlahy</h1>
            <p className="text-lg sm:text-xl opacity-90 mb-8 max-w-2xl mx-auto">
              Nadčasová elegance přírodního dřeva pro váš domov
            </p>
          </div>
        }
      />
      
      <Section
        content={
          <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="/wooden-floor-kitchen.jpg"
                alt="Dřevěná podlaha v moderní kuchyni"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="space-y-6">
              <h2 className="text-3xl sm:text-4xl font-light">Proč dřevěné podlahy?</h2>
              <div className="space-y-4">
                <p className="text-gray-600">
                  Dřevěné podlahy jsou symbolem luxusu a kvality. Přinášejí do interiéru přirozenou krásu a teplo přírodního materiálu.
                </p>
                <ul className="space-y-3">
                  {[
                    'Přírodní a ekologický materiál',
                    'Dlouhá životnost',
                    'Možnost renovace',
                    'Zvyšuje hodnotu nemovitosti',
                    'Jedinečná struktura každého kusu',
                    'Přirozený a zdravý materiál'
                  ].map((benefit) => (
                    <li key={benefit} className="flex items-center gap-3">
                      <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
              <Button href="#kontakt" className="mt-6">Nezávazná konzultace</Button>
            </div>
          </div>
        }
      />
    </>
  );
};

export default WoodenFlooringPage;