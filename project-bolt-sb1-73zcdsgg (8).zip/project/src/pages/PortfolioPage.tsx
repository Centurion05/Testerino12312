import React from 'react';
import Section from '../components/Section';
import { ArrowRight } from 'lucide-react';

const projects = [
  {
    title: 'Vinylová podlaha v bytě',
    description: 'Moderní vinylová podlaha s dekorem dřeva v třípokojovém bytě',
    image: 'https://images.unsplash.com/photo-1581858726788-75bc0f6a952d?auto=format&fit=crop&q=80&w=800',
    type: 'Vinyl',
    location: 'Brno-střed',
    area: '68 m²'
  },
  {
    title: 'Dřevěná podlaha v rodinném domě',
    description: 'Masivní dubová podlaha v novostavbě rodinného domu',
    image: 'https://images.unsplash.com/photo-1516455590571-18256e5bb9ff?auto=format&fit=crop&q=80&w=800',
    type: 'Dřevo',
    location: 'Brno-Královo Pole',
    area: '120 m²'
  },
  {
    title: 'Laminátová podlaha v kanceláři',
    description: 'Odolná laminátová podlaha pro komerční prostory',
    image: 'https://images.unsplash.com/photo-1502005229762-cf1b2da7c5d6?auto=format&fit=crop&q=80&w=800',
    type: 'Laminát',
    location: 'Brno-Žabovřesky',
    area: '85 m²'
  },
  {
    title: 'Vinylová podlaha v kuchyni',
    description: 'Voděodolná vinylová podlaha s dekorem dlažby',
    image: 'https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&q=80&w=800',
    type: 'Vinyl',
    location: 'Brno-Líšeň',
    area: '22 m²'
  },
  {
    title: 'Koberec v kancelářích',
    description: 'Zátěžový koberec pro open space kanceláře',
    image: 'https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&q=80&w=800',
    type: 'Koberec',
    location: 'Brno-Štýřice',
    area: '250 m²'
  },
  {
    title: 'Marmoleum ve škole',
    description: 'Ekologické marmoleum pro základní školu',
    image: 'https://images.unsplash.com/photo-1594940018077-e123681fb35c?auto=format&fit=crop&q=80&w=800',
    type: 'Marmoleum',
    location: 'Brno-Bystrc',
    area: '450 m²'
  }
];

const PortfolioPage = () => {
  return (
    <Section
      title="Ukázky prací"
      subtitle="Naše realizované projekty"
      content={
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project) => (
              <div 
                key={project.title} 
                className="group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-medium">{project.title}</h3>
                    <ArrowRight className="w-5 h-5 transform group-hover:translate-x-2 transition-transform" />
                  </div>
                  <p className="text-gray-600 mb-4">{project.description}</p>
                  <div className="space-y-1 text-sm text-gray-500">
                    <p>Typ: {project.type}</p>
                    <p>Lokalita: {project.location}</p>
                    <p>Plocha: {project.area}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      }
      className="bg-gray-50"
    />
  );
};

export default PortfolioPage;