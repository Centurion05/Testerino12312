import React from 'react';
import Section from '../components/Section';
import Button from '../components/Button';

const VinylFlooringPage = () => {
  return (
    <>
      <Section
        backgroundImage="https://images.unsplash.com/photo-1581858726788-75bc0f6a952d?auto=format&fit=crop&q=80"
        dark
        content={
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-light mb-6">Vinylové podlahy</h1>
            <p className="text-lg sm:text-xl opacity-90 mb-8 max-w-2xl mx-auto">
              Moderní a odolné vinylové podlahy pro každý prostor
            </p>
          </div>
        }
      />
      
      <Section
        content={
          <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1581858726788-75bc0f6a952d?auto=format&fit=crop&q=80"
                alt="Vinylová podlaha"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="space-y-6">
              <h2 className="text-3xl sm:text-4xl font-light">Proč vinylové podlahy?</h2>
              <div className="space-y-4">
                <p className="text-gray-600">
                  Vinylové podlahy představují moderní řešení pro váš domov či komerční prostor. Kombinují v sobě estetiku, odolnost a snadnou údržbu.
                </p>
                <ul className="space-y-3">
                  {[
                    'Vysoká odolnost proti opotřebení',
                    'Voděodolnost',
                    'Snadná údržba',
                    'Tichý a teplý povrch',
                    'Široká škála designů',
                    'Vhodné pro podlahové vytápění'
                  ].map((benefit) => (
                    <li key={benefit} className="flex items-center gap-3">
                      <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
              <Button href="#kontakt" className="mt-6">Nezávazná konzultace</Button>
            </div>
          </div>
        }
      />
    </>
  );
};

export default VinylFlooringPage;