import React from 'react';
import Section from '../components/Section';
import PricingTable from '../components/pricing/PricingTable';

const PricingPage = () => {
  return (
    <Section
      title="Ceník služeb"
      subtitle="Kompletní přehled cen našich služeb"
      content={<PricingTable />}
      className="bg-gray-50/50"
    />
  );
};

export default PricingPage;