import React from 'react';
import Section from '../components/Section';
import Button from '../components/Button';

const LaminateFlooringPage = () => {
  const imageUrl = "https://images.unsplash.com/photo-1502005229762-cf1b2da7c5d6?auto=format&fit=crop&q=80";
  
  return (
    <>
      <Section
        backgroundImage={imageUrl}
        dark
        content={
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-light mb-6">Laminátové podlahy</h1>
            <p className="text-lg sm:text-xl opacity-90 mb-8 max-w-2xl mx-auto">
              Praktické a stylové řešení pro moderní bydlení
            </p>
          </div>
        }
      />
      
      <Section
        content={
          <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src={imageUrl}
                alt="Laminátová podlaha v obývacím pokoji"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="space-y-6">
              <h2 className="text-3xl sm:text-4xl font-light">Proč laminátové podlahy?</h2>
              <div className="space-y-4">
                <p className="text-gray-600">
                  Laminátové podlahy nabízí ideální kombinaci vzhledu, odolnosti a dostupnosti. Jsou perfektní volbou pro moderní domácnosti.
                </p>
                <ul className="space-y-3">
                  {[
                    'Výborný poměr cena/výkon',
                    'Snadná údržba',
                    'Odolnost proti poškrábání',
                    'Široký výběr designů',
                    'Rychlá instalace',
                    'UV stabilní'
                  ].map((benefit) => (
                    <li key={benefit} className="flex items-center gap-3">
                      <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
              <Button href="#kontakt" className="mt-6">Nezávazná konzultace</Button>
            </div>
          </div>
        }
      />
    </>
  );
};

export default LaminateFlooringPage;