import React from 'react';
import Section from '../components/Section';
import Button from '../components/Button';

const MarmoleumPage = () => {
  return (
    <>
      <Section
        backgroundImage="/marmoleum.jpg"
        dark
        content={
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-light mb-6">Marmoleum</h1>
            <p className="text-lg sm:text-xl opacity-90 mb-8 max-w-2xl mx-auto">
              Ekologické a odolné podlahové krytiny
            </p>
          </div>
        }
      />
      
      <Section
        content={
          <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="/marmoleum.jpg"
                alt="Marmoleum v moderním interiéru"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="space-y-6">
              <h2 className="text-3xl sm:text-4xl font-light">Proč marmoleum?</h2>
              <div className="space-y-4">
                <p className="text-gray-600">
                  Marmoleum je přírodní podlahová krytina vyrobená z obnovitelných materiálů. Kombinuje ekologický přístup s moderním designem.
                </p>
                <ul className="space-y-3">
                  {[
                    'Ekologický materiál',
                    'Antibakteriální vlastnosti',
                    'Dlouhá životnost',
                    'Snadná údržba',
                    'Vhodné pro alergiky',
                    'Přírodní složení'
                  ].map((benefit) => (
                    <li key={benefit} className="flex items-center gap-3">
                      <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
              <Button href="#kontakt" className="mt-6">Nezávazná konzultace</Button>
            </div>
          </div>
        }
      />
    </>
  );
};

export default MarmoleumPage;