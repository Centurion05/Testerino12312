import React from 'react';
import Section from '../components/Section';
import ContactForm from '../components/ContactForm';
import ContactInfo from '../components/ContactInfo';

const ContactPage = () => {
  return (
    <Section
      title="Kontaktujte Nás"
      subtitle="Jsme tu pro vás každý pracovní den"
      content={
        <div className="max-w-4xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-medium mb-4">Kontaktní informace</h3>
                <ContactInfo />
              </div>
              <div>
                <h3 className="text-xl font-medium mb-4">Otevírací doba</h3>
                <div className="space-y-2 text-gray-600">
                  <p>Pondělí - Pátek: 8:00 - 17:00</p>
                  <p>Sobota - Neděle: Dle dohody</p>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-medium mb-4">Kde nás najdete</h3>
                <div className="aspect-[4/3] w-full">
                  <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2607.375890666836!2d16.60661561571675!3d49.19719787932366!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4712945a63b6a4c1%3A0x7a1b0b1b9b2b0b0b!2zxIxlc2vDoSAxNSwgNjAyIDAwIEJybm8!5e0!3m2!1scs!2scz!4v1620000000000!5m2!1scs!2scz" 
                    className="w-full h-full rounded-lg"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                  />
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-medium mb-6">Napište nám</h3>
              <ContactForm />
            </div>
          </div>
        </div>
      }
      className="bg-gray-50/50"
    />
  );
};

export default ContactPage;