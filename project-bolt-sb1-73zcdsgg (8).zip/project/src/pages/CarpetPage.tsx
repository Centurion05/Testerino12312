import React from 'react';
import Section from '../components/Section';
import Button from '../components/Button';

const CarpetPage = () => {
  return (
    <>
      <Section
        backgroundImage="/koberec.jpg"
        dark
        content={
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-light mb-6">Koberce</h1>
            <p className="text-lg sm:text-xl opacity-90 mb-8 max-w-2xl mx-auto">
              Komfort a útulnost pro váš domov
            </p>
          </div>
        }
      />
      
      <Section
        content={
          <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="/koberec.jpg"
                alt="Luxusní koberec v obývacím pokoji"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div className="space-y-6">
              <h2 className="text-3xl sm:text-4xl font-light">Proč koberce?</h2>
              <div className="space-y-4">
                <p className="text-gray-600">
                  Koberce přinášejí do prostoru teplo, komfort a útulnost. Jsou ideální volbou pro vytvoření příjemné atmosféry.
                </p>
                <ul className="space-y-3">
                  {[
                    'Příjemný na dotek',
                    'Tepelná izolace',
                    'Akustické vlastnosti',
                    'Bezpečnost pro děti',
                    'Široká škála barev a vzorů',
                    'Snadná výměna'
                  ].map((benefit) => (
                    <li key={benefit} className="flex items-center gap-3">
                      <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
              <Button href="#kontakt" className="mt-6">Nezávazná konzultace</Button>
            </div>
          </div>
        }
      />
    </>
  );
};

export default CarpetPage;