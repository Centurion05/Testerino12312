export interface MenuItem {
  label: string;
  to: string;
  hasSubmenu?: boolean;
}