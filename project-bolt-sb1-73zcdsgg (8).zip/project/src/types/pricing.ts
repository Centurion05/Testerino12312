export interface PricingItem {
  service: string;
  price: string;
}

export interface PricingCategory {
  title: string;
  items: PricingItem[];
}