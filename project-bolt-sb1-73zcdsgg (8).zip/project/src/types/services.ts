export interface Service {
  title: string;
  description: string;
  image: string;
  alt?: string;
  path: string;
}