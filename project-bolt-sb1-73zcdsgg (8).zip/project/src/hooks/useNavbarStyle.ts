import { useLocation } from 'react-router-dom';

export function useNavbarStyle(isScrolled: boolean, isServicesOpen: boolean) {
  const location = useLocation();
  
  // Pages that should always have white background and black text
  const whiteBackgroundPages = ['/kontakt', '/ukazky-praci', '/cenik'];
  
  const shouldUseWhiteNav = 
    isScrolled || 
    isServicesOpen || 
    whiteBackgroundPages.includes(location.pathname);

  return {
    background: shouldUseWhiteNav ? 'bg-white' : 'bg-transparent',
    textColor: shouldUseWhiteNav ? 'text-black' : 'text-white'
  };
}