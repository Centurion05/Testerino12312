import React from 'react';
import { Routes, Route } from 'react-router-dom';
import HomePage from '../pages/HomePage';
import PricingPage from '../pages/PricingPage';
import VinylFlooringPage from '../pages/VinylFlooringPage';
import WoodenFlooringPage from '../pages/WoodenFlooringPage';
import LaminateFlooringPage from '../pages/LaminateFlooringPage';
import CarpetPage from '../pages/CarpetPage';
import MarmoleumPage from '../pages/MarmoleumPage';
import ContactPage from '../pages/ContactPage';
import PortfolioPage from '../pages/PortfolioPage';

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/cenik" element={<PricingPage />} />
      <Route path="/vinylove-podlahy" element={<VinylFlooringPage />} />
      <Route path="/drevene-podlahy" element={<WoodenFlooringPage />} />
      <Route path="/laminatove-podlahy" element={<LaminateFlooringPage />} />
      <Route path="/koberce" element={<CarpetPage />} />
      <Route path="/marmoleum" element={<MarmoleumPage />} />
      <Route path="/kontakt" element={<ContactPage />} />
      <Route path="/ukazky-praci" element={<PortfolioPage />} />
    </Routes>
  );
};

export default AppRoutes;