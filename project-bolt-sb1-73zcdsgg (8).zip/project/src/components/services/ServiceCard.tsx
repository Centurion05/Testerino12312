import React from 'react';
import { Link } from 'react-router-dom';
import { Service } from '../../types/services';

interface ServiceCardProps {
  service: Service;
  onClose: () => void;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ service, onClose }) => {
  return (
    <Link 
      to={service.path}
      className="group cursor-pointer"
      onClick={onClose}
    >
      <div className="relative overflow-hidden rounded-lg">
        <img 
          src={service.image} 
          alt={service.alt || service.title}
          className="w-full h-48 object-cover transform transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-300" />
      </div>
      <div className="mt-4">
        <h3 className="text-lg font-medium">{service.title}</h3>
        <p className="text-sm text-gray-600 mt-1">{service.description}</p>
      </div>
    </Link>
  );
};

export default ServiceCard;