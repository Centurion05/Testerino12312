import React from 'react';
import Section from '../Section';
import Button from '../Button';
import { ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';

const HeroSection = () => {
  return (
    <Section
      backgroundImage="https://images.unsplash.com/photo-1581858726788-75bc0f6a952d?auto=format&fit=crop&q=80"
      content={
        <div className="max-w-4xl mx-auto text-white">
          <div className="space-y-6 sm:space-y-8 mb-12">
            <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-extralight tracking-tight">
              <span className="block">Dokonalé</span>
              <span className="block">podlahy</span>
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl font-light tracking-wide max-w-xl">
              Profesionální instalace a renovace podlah v Brně a okolí s 10letou zárukou
            </p>
            <div>
              <Button href="#kontakt">KONTAKTOVAT</Button>
            </div>
          </div>
          
          <Link 
            to="/#ukazky" 
            className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white hover:opacity-75 transition-opacity"
          >
            <ChevronDown size={32} className="animate-bounce" />
          </Link>
        </div>
      }
    />
  );
};

export default HeroSection;