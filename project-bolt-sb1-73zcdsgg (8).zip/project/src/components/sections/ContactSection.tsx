import React from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import Section from '../Section';
import ContactForm from '../ContactForm';
import ContactInfo from '../ContactInfo';

const ContactSection = () => {
  return (
    <Section
      title="Kontaktujte Nás"
      subtitle="Jsme tu pro vás"
      content={
        <div className="max-w-4xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ContactInfo />
            <ContactForm />
          </div>
        </div>
      }
    />
  );
};

export default ContactSection;