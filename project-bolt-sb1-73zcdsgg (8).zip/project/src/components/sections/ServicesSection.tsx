import React from 'react';
import { Link } from 'react-router-dom';
import Section from '../Section';

const ServicesSection = () => {
  const services = [
    {
      title: 'Vinylové Podlahy',
      description: 'Moderní a odolné vinylové podlahy pro každý prostor.',
      path: '/vinylove-podlahy'
    },
    {
      title: 'Dřevěné Podlahy',
      description: 'Instalace a renovace všech typů dřevěných podlah.',
      path: '/drevene-podlahy'
    },
    {
      title: 'Laminátové Podlahy',
      description: 'Kvalitní laminátové podlahy s profesionální pokládkou.',
      path: '/laminatove-podlahy'
    },
    {
      title: 'Koberce',
      description: 'Široký výběr koberců pro domácí i komerční prostory.',
      path: '/koberce'
    },
    {
      title: 'Marmoleum',
      description: 'Ekologické a odolné podlahové krytiny z přírodních materiálů.',
      path: '/marmoleum'
    },
  ];

  return (
    <Section
      id="sluzby"
      backgroundImage="https://images.unsplash.com/photo-1502005229762-cf1b2da7c5d6?auto=format&fit=crop&q=80"
      title="Naše Služby"
      subtitle="Kompletní řešení podlah pro váš domov"
      dark
      content={
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {services.map((service) => (
            <Link 
              key={service.title}
              to={service.path}
              className="block group"
            >
              <div className="bg-white/10 backdrop-blur-md p-6 rounded-lg transform hover:scale-105 transition-all duration-300">
                <h3 className="text-xl sm:text-2xl font-bold mb-4">{service.title}</h3>
                <p className="text-gray-200">{service.description}</p>
              </div>
            </Link>
          ))}
        </div>
      }
    />
  );
};

export default ServicesSection;