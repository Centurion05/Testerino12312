import React from 'react';
import Section from '../Section';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const projects = [
  {
    title: 'Vinylová podlaha v bytě',
    image: 'https://images.unsplash.com/photo-1581858726788-75bc0f6a952d?auto=format&fit=crop&q=80&w=800',
    type: 'Vinyl',
    location: 'Brno-střed'
  },
  {
    title: 'Dřevěná podlaha v rodinném domě',
    image: 'https://images.unsplash.com/photo-1516455590571-18256e5bb9ff?auto=format&fit=crop&q=80&w=800',
    type: 'Dřevo',
    location: 'Brno-Královo Pole'
  },
  {
    title: 'Laminátová podlaha v kanceláři',
    image: 'https://images.unsplash.com/photo-1502005229762-cf1b2da7c5d6?auto=format&fit=crop&q=80&w=800',
    type: 'Laminát',
    location: 'Brno-Žabovřesky'
  }
];

const GallerySection = () => {
  return (
    <Section
      title="Naše práce"
      subtitle="Ukázky realizovaných projektů"
      content={
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {projects.map((project) => (
              <div 
                key={project.title} 
                className="group relative overflow-hidden rounded-lg cursor-pointer"
              >
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6 text-white">
                  <h3 className="text-xl font-medium mb-2">{project.title}</h3>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm opacity-75">{project.type}</p>
                      <p className="text-sm opacity-75">{project.location}</p>
                    </div>
                    <ArrowRight className="w-5 h-5 transform group-hover:translate-x-2 transition-transform" />
                  </div>
                </div>
              </div>
            ))}

            <Link 
              to="/ukazky-praci"
              className="group relative overflow-hidden rounded-lg cursor-pointer bg-black/5 hover:bg-black/10 transition-colors flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-gray-300 hover:border-gray-400"
            >
              <div className="mb-4">
                <ArrowRight className="w-12 h-12 transform group-hover:translate-x-2 transition-transform" />
              </div>
              <h3 className="text-xl font-medium mb-2">Chci vidět další ukázky</h3>
              <p className="text-sm text-gray-600">Prohlédněte si více našich realizovaných projektů</p>
            </Link>
          </div>
        </div>
      }
    />
  );
};

export default GallerySection;