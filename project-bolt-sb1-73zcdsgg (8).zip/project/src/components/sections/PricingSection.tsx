import React from 'react';
import Section from '../Section';
import PricingTable from '../pricing/PricingTable';

const PricingSection = () => {
  return (
    <Section
      title="Ceník"
      subtitle="Transparentní ceny pro všechny naše služby"
      content={<PricingTable />}
    />
  );
};

export default PricingSection;