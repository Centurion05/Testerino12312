import React from 'react';
import Section from '../Section';
import { PhoneCall, ClipboardCheck, Wrench, CheckCircle } from 'lucide-react';
import { ProcessStep } from '../../types/process';

const steps: ProcessStep[] = [
  {
    icon: PhoneCall,
    title: 'Konzultace',
    description: 'Bezplatná konzultace a zaměření prostoru',
  },
  {
    icon: ClipboardCheck,
    title: 'Nabídka',
    description: 'Detailní cenová nabídka do 24 hodin',
  },
  {
    icon: Wrench,
    title: 'Realizace',
    description: 'Profesionální instalace s maximální péčí',
  },
  {
    icon: CheckCircle,
    title: 'Záruka',
    description: '10 let záruka na práci a servis',
  },
];

const ProcessSection = () => {
  return (
    <Section
      title="Jak to funguje"
      subtitle="Jednoduchý proces od první konzultace po finální realizaci"
      content={
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <ProcessStepCard 
                key={step.title} 
                step={step} 
                isLast={index === steps.length - 1} 
              />
            ))}
          </div>
        </div>
      }
    />
  );
};

interface ProcessStepCardProps {
  step: ProcessStep;
  isLast: boolean;
}

const ProcessStepCard: React.FC<ProcessStepCardProps> = ({ step, isLast }) => {
  const { icon: Icon, title, description } = step;
  
  return (
    <div className="text-center">
      <div className="relative">
        <Icon className="w-12 h-12 mx-auto mb-4" />
        {!isLast && (
          <div className="hidden md:block absolute top-6 left-full w-full h-0.5 bg-gray-200" />
        )}
      </div>
      <h3 className="text-xl font-medium mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

export default ProcessSection;