import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useScrollDirection } from '../hooks/useScrollDirection';
import { useNavbarStyle } from '../hooks/useNavbarStyle';
import MobileMenu from './navigation/MobileMenu';
import DesktopMenu from './navigation/DesktopMenu';
import { MenuItem } from '../types/navigation';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const isVisible = useScrollDirection();
  const { background, textColor } = useNavbarStyle(isScrolled, isServicesOpen);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems: MenuItem[] = [
    { label: 'Domů', to: '/' },
    { label: 'Služby', to: '/#sluzby', hasSubmenu: true },
    { label: 'Ceník', to: '/cenik' },
    { label: 'Ukázky práce', to: '/ukazky-praci' },
    { label: 'Kontakt', to: '/kontakt' },
  ];

  return (
    <>
      <nav
        className={`fixed w-full z-50 transition-all duration-300 ${
          isVisible ? 'translate-y-0' : 'md:-translate-y-full'
        } ${background}`}
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex justify-between items-center h-20 relative">
            <Link to="/" className="flex-shrink-0 relative z-50">
              <span className={`logo-text text-2xl transition-colors duration-300 ${textColor}`}>
                Podlahy
              </span>
              <span className={`logo-text text-2xl ml-2 transition-colors duration-300 ${textColor}`}>
                Brno
              </span>
            </Link>
            
            <DesktopMenu 
              menuItems={menuItems} 
              textColor={textColor}
              onServicesOpen={(open) => setIsServicesOpen(open)}
            />

            <button
              className={`md:hidden px-4 py-2 text-sm rounded transition-all duration-300 ${
                textColor === 'text-black' 
                  ? 'bg-black/5 hover:bg-black/10' 
                  : 'bg-white/10 hover:bg-white/20'
              } ${textColor}`}
              onClick={() => setIsMenuOpen(true)}
            >
              <span className="text-base">N</span>abídka
            </button>
          </div>
        </div>
      </nav>

      <MobileMenu 
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
      />
    </>
  );
};

export default Navbar;