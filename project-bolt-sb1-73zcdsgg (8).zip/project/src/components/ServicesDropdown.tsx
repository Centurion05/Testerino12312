import React from 'react';
import { Link } from 'react-router-dom';
import ServiceCard from './services/ServiceCard';
import { services } from '../data/services';

interface ServicesDropdownProps {
  isOpen: boolean;
  onMouseEnter: () => void;
  onMouseLeave: () => void;
  onClose: () => void;
}

const ServicesDropdown: React.FC<ServicesDropdownProps> = ({ 
  isOpen, 
  onMouseEnter, 
  onMouseLeave,
  onClose 
}) => {
  return (
    <div 
      className={`services-dropdown fixed left-0 right-0 bg-white text-black shadow-lg ${isOpen ? 'open' : ''}`}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service) => (
            <ServiceCard 
              key={service.title}
              service={service}
              onClose={onClose}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ServicesDropdown;