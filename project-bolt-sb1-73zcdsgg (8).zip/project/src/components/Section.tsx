import React from 'react';
import { ChevronDown } from 'lucide-react';

interface SectionProps {
  backgroundImage?: string;
  title?: string;
  subtitle?: string;
  content?: React.ReactNode;
  dark?: boolean;
  showScrollIndicator?: boolean;
  fullHeight?: boolean;
  className?: string;
}

const Section: React.FC<SectionProps> = ({
  backgroundImage,
  title,
  subtitle,
  content,
  dark,
  showScrollIndicator,
  fullHeight = true,
  className = '',
}) => {
  return (
    <section
      className={`relative w-full overflow-x-hidden flex flex-col items-center justify-center py-16 sm:py-20 md:py-24 ${
        fullHeight ? 'min-h-[100dvh]' : ''
      } ${dark ? 'text-white' : 'text-black'} ${className}`}
      style={
        backgroundImage
          ? {
              backgroundImage: `linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)), url(${backgroundImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundAttachment: 'fixed',
            }
          : {}
      }
    >
      <div className="w-full px-4 sm:px-6 lg:px-8">
        {(title || subtitle) && (
          <div className="text-center space-y-3 sm:space-y-4 mb-8 sm:mb-10 md:mb-12">
            {title && (
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-light tracking-tight">
                {title}
              </h2>
            )}
            {subtitle && (
              <p className="text-base sm:text-lg md:text-xl font-light max-w-2xl mx-auto">
                {subtitle}
              </p>
            )}
          </div>
        )}
        {content && <div className="w-full">{content}</div>}
      </div>

      {showScrollIndicator && (
        <a href="#ukazky" className="absolute bottom-8 animate-bounce cursor-pointer">
          <ChevronDown size={32} className="text-white" />
        </a>
      )}
    </section>
  );
};

export default Section;