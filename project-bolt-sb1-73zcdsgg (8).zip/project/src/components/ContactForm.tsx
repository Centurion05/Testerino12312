import React from 'react';

const ContactForm = () => {
  return (
    <form className="space-y-4">
      <input
        type="text"
        placeholder="Jméno"
        className="w-full p-2 rounded bg-gray-100"
      />
      <input
        type="email"
        placeholder="Email"
        className="w-full p-2 rounded bg-gray-100"
      />
      <textarea
        placeholder="Zpráva"
        rows={4}
        className="w-full p-2 rounded bg-gray-100"
      />
      <button className="bg-black text-white px-8 py-2 rounded hover:bg-gray-800 transition-colors">
        Odeslat
      </button>
    </form>
  );
};

export default ContactForm;