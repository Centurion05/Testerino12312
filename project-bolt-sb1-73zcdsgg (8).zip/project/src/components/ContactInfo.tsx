import React from 'react';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';

const ContactInfo = () => {
  const contactDetails = [
    { Icon: Phone, text: '+420 123 456 789' },
    { Icon: Mail, text: 'info@podlahybrno.cz' },
    { Icon: MapPin, text: 'Česká 15, Brno' },
    { Icon: Clock, text: 'Po-Pá: 8:00 - 17:00' },
  ];

  return (
    <div className="space-y-6">
      {contactDetails.map(({ Icon, text }) => (
        <div key={text} className="flex items-center space-x-4">
          <Icon className="w-6 h-6" />
          <span>{text}</span>
        </div>
      ))}
    </div>
  );
};

export default ContactInfo;