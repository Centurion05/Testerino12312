import React from 'react';
import { pricingData } from '../../data/pricing';
import PricingCategory from './PricingCategory';
import PricingInfo from './PricingInfo';

const PricingTable: React.FC = () => {
  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6">
      <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
        <div className="divide-y divide-gray-100">
          {pricingData.map((category) => (
            <PricingCategory key={category.title} category={category} />
          ))}
        </div>
        <PricingInfo />
      </div>
    </div>
  );
};

export default PricingTable;