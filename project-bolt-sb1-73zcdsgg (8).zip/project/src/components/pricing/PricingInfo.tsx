import React from 'react';

const PricingInfo: React.FC = () => {
  return (
    <div className="bg-gray-50/50 px-3 sm:px-4 md:px-6 py-4 sm:py-6">
      <div className="max-w-3xl mx-auto">
        <h4 className="text-sm sm:text-base font-medium text-gray-900 mb-2 sm:mb-3">Důležité informace</h4>
        <ul className="space-y-1.5 sm:space-y-2 text-[13px] sm:text-sm text-gray-600 [&>li]:pl-4 [&>li]:relative [&>li]:before:content-['•'] [&>li]:before:absolute [&>li]:before:left-0 [&>li]:before:text-gray-400">
          <li>Ceny uvedeny za m² bez DPH od 20 m² do 50 m²</li>
          <li>Ceny do 20 m² řešíme individuálně</li>
          <li>Pro plochy nad 50 m² zpracujeme individuální cenovou nabídku</li>
          <li>Při vlastním materiálu navýšení ceny o 10-15%</li>
        </ul>
        
        <h4 className="text-sm sm:text-base font-medium text-gray-900 mt-5 sm:mt-6 mb-2 sm:mb-3">Dodatečné služby zdarma</h4>
        <ul className="space-y-1.5 sm:space-y-2 text-[13px] sm:text-sm text-gray-600 [&>li]:pl-4 [&>li]:relative [&>li]:before:content-['•'] [&>li]:before:absolute [&>li]:before:left-0 [&>li]:before:text-gray-400">
          <li>Zaměření a poradenství</li>
          <li>Vypracování cenové nabídky</li>
          <li>První měření vlhkosti CM metodou</li>
          <li>Orientační měření vlhkosti (3×)</li>
        </ul>
      </div>
    </div>
  );
};

export default PricingInfo;