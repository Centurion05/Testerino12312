import React from 'react';
import { PricingItem } from '../../types/pricing';

interface PricingCardProps {
  service: string;
  price: string;
}

const PricingCard: React.FC<PricingCardProps> = ({ service, price }) => {
  return (
    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1.5 sm:gap-4 p-3 sm:p-4 hover:bg-gray-50 transition-all duration-300 ease-in-out">
      <span className="text-[13px] leading-tight sm:text-sm md:text-base text-gray-700 font-light">{service}</span>
      <span className="text-sm sm:text-base font-medium text-gray-900 sm:text-right tracking-wide whitespace-nowrap">{price}</span>
    </div>
  );
};

export default PricingCard;