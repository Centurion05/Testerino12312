import React from 'react';
import PricingCard from './PricingCard';
import { PricingCategory as PricingCategoryType } from '../../types/pricing';

interface PricingCategoryProps {
  category: PricingCategoryType;
}

const PricingCategory: React.FC<PricingCategoryProps> = ({ category }) => {
  return (
    <div className="border-b last:border-b-0 transition-all duration-300 ease-in-out">
      <div className="bg-gray-50/50 px-3 sm:px-4 md:px-6 py-3 sm:py-4">
        <h3 className="text-sm sm:text-base md:text-lg font-medium text-gray-900">{category.title}</h3>
      </div>
      <div className="divide-y divide-gray-100">
        {category.items.map((item) => (
          <PricingCard key={item.service} {...item} />
        ))}
      </div>
    </div>
  );
};

export default PricingCategory;