import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  href: string;
  className?: string;
}

const Button: React.FC<ButtonProps> = ({ children, href, className = '' }) => {
  return (
    <a 
      href={href}
      className={`inline-block px-8 py-3 bg-white text-black hover:bg-black hover:text-white transition-colors duration-300 tracking-wider text-sm rounded-sm ${className}`}
    >
      {children}
    </a>
  );
};

export default Button;