import React from 'react';
import { Link } from 'react-router-dom';
import { services } from '../../data/services';

interface MobileServicesMenuProps {
  onBack: () => void;
  onClose: () => void;
}

const MobileServicesMenu: React.FC<MobileServicesMenuProps> = ({ onBack, onClose }) => {
  return (
    <div className="fixed inset-0 bg-white">
      <div className="flex justify-between items-center p-6">
        <button
          onClick={onBack}
          className="text-black text-2xl"
        >
          ‹
        </button>
        <button onClick={onClose} className="text-black text-2xl">
          ×
        </button>
      </div>

      <div className="px-8 py-4 space-y-8">
        {services.map((service) => (
          <Link
            key={service.title}
            to={service.path}
            className="flex items-start space-x-4 group"
            onClick={onClose}
          >
            <div className="w-24 h-24 flex-shrink-0">
              <img
                src={service.image}
                alt={service.alt || service.title}
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
            <div>
              <h3 className="text-xl text-black group-hover:opacity-70 transition-opacity">
                {service.title}
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                {service.description}
              </p>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default MobileServicesMenu;