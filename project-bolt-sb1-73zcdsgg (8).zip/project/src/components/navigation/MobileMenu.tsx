import React from 'react';
import { X, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { MenuItem } from '../../types/navigation';
import MobileServicesMenu from './MobileServicesMenu';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, onClose }) => {
  const [showServices, setShowServices] = React.useState(false);

  const menuItems: MenuItem[] = [
    { label: 'Domů', to: '/' },
    { label: 'Služby', to: '/#sluzby', hasSubmenu: true },
    { label: 'Ceník', to: '/cenik' },
    { label: 'Ukázky práce', to: '/#ukazky' },
    { label: 'Kontakt', to: '/#kontakt' },
  ];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-white z-50">
      <div className="flex justify-end p-6">
        <button onClick={onClose} className="text-black">
          <X size={24} />
        </button>
      </div>

      {showServices ? (
        <MobileServicesMenu onBack={() => setShowServices(false)} onClose={onClose} />
      ) : (
        <div className="px-8 py-4">
          {menuItems.map((item) => (
            <div key={item.label} className="mb-8">
              {item.hasSubmenu ? (
                <button
                  onClick={() => setShowServices(true)}
                  className="text-xl text-black hover:opacity-70 transition-opacity w-full flex justify-between items-center"
                >
                  {item.label}
                  <ChevronRight size={20} className="text-gray-400" />
                </button>
              ) : (
                <Link
                  to={item.to}
                  className="text-xl text-black hover:opacity-70 transition-opacity block"
                  onClick={onClose}
                >
                  {item.label}
                </Link>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MobileMenu;