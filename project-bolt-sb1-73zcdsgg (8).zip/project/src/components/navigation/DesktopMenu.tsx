import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import ServicesDropdown from './ServicesDropdown';
import { MenuItem } from '../../types/navigation';

interface DesktopMenuProps {
  menuItems: MenuItem[];
  textColor: string;
  onServicesOpen: (isOpen: boolean) => void;
}

const DesktopMenu: React.FC<DesktopMenuProps> = ({ 
  menuItems, 
  textColor,
  onServicesOpen 
}) => {
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout>();

  const handleMouseEnter = (hasSubmenu?: boolean) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    
    if (!hasSubmenu && isServicesOpen) {
      setIsServicesOpen(false);
      onServicesOpen(false);
    }
    
    if (hasSubmenu) {
      setIsServicesOpen(true);
      onServicesOpen(true);
    }
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setIsServicesOpen(false);
      onServicesOpen(false);
    }, 100);
  };

  return (
    <>
      <div 
        className="hidden md:flex space-x-10"
        onMouseLeave={handleMouseLeave}
      >
        {menuItems.map((item) => (
          <div
            key={item.label}
            onMouseEnter={() => handleMouseEnter(item.hasSubmenu)}
            className="relative z-50"
          >
            <Link 
              to={item.to}
              className={`menu-text text-sm hover:opacity-75 transition-colors duration-300 ${textColor}`}
              onClick={() => {
                setIsServicesOpen(false);
                onServicesOpen(false);
              }}
            >
              {item.label}
            </Link>
          </div>
        ))}
      </div>

      <ServicesDropdown 
        isOpen={isServicesOpen} 
        onMouseEnter={() => handleMouseEnter(true)}
        onMouseLeave={handleMouseLeave}
        onClose={() => {
          setIsServicesOpen(false);
          onServicesOpen(false);
        }}
      />
    </>
  );
};

export default DesktopMenu;