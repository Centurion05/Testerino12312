import React from 'react';
import { Link } from 'react-router-dom';
import { services } from '../../data/services';

interface ServicesDropdownProps {
  isOpen: boolean;
  onMouseEnter: () => void;
  onMouseLeave: () => void;
  onClose: () => void;
}

const ServicesDropdown: React.FC<ServicesDropdownProps> = ({ 
  isOpen, 
  onMouseEnter, 
  onMouseLeave,
  onClose 
}) => {
  return (
    <div 
      className={`fixed left-0 right-0 top-0 bg-white text-black shadow-lg transition-all duration-300 z-40 ${
        isOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
      }`}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
    >
      <div className="h-20" /> {/* Spacer for navbar height */}
      <div className="border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service) => (
              <Link
                key={service.title}
                to={service.path}
                className="group"
                onClick={onClose}
              >
                <div className="relative overflow-hidden rounded-lg mb-4">
                  <img 
                    src={service.image} 
                    alt={service.alt || service.title}
                    className="w-full h-48 object-cover transform transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors duration-300" />
                </div>
                <h3 className="menu-text text-lg text-black">{service.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{service.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServicesDropdown;